#!/bin/sh

echo "Adding X server"
sudo setup-xorg-base

echo -e "\nAdding dependencies"
sudo apk add libx11-dev libxft-dev libxrandr-dev pkgconf

echo -e "\nAddding key binder"
sudo apk add xbindkeys

echo  "Build and Adding window manager"
$RUN_DIR/script/archiver echinus

echo "Adding fonts"
sudo apk add font-noto-cjk

echo "Adding sound base"
sudo apk add alsa-utils alsa-lib alsaconf
sudo rc-update add alsa

echo "Adding building tools"
sudo apk add build-base gcc abuild binutils cmake extra-cmake-modules
