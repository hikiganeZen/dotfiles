#!/bin/sh

export RUN_DIR=/home/front/linuxdriver

# Set chmod wrapper executable
if [ ! -x "$RUN_DIR/script/all_chmod_x" ]; then
	chmod +x $RUN_DIR/script/all_chmod_x
fi

# Set other script executable
$RUN_DIR/script/all_chmod_x $RUN_DIR/script 
$RUN_DIR/script/all_chmod_x $RUN_DIR/alpine 
$RUN_DIR/script/all_chmod_x $RUN_DIR/alpine/install 

echo -e "Welcome to Setup_Manager!\n"

read -n 1 -s -r -p "Preceed to pull dotfiles [press any key to continue] : "
echo -e "\n"
#$RUN_DIR/script/pull_dot.sh

echo -e "Entering program setup:\nThis will gonna take so much time.\n"
read -n 1 -s -r -p "[press any key to continue] : "
#$RUN_DIR/alpine/apk_bulk.sh

echo -e "\nThank YOU!"

