#!/bin/sh

DOT_REPO=https://github.com/hikiganeZen/dotfiles
DOT_DEST=$HOME
DOT_FOLDER=`basename $DOT_REPO`
# read -p "Enter your github URL : " DOT_REPO

git -C $DOT_DEST clone $DOT_REPO
for file in `ls -A $DOT_DEST/$DOT_FOLDER`; do
	mv $DOT_DEST/$DOT_FOLDER/$file $DOT_DEST
	rmdir $DOT_DEST/$DOT_FOLDER
done
